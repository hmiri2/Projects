<?php require_once('header.php') ?>

<div class="w-100">
    <p class="mt-5 pt-5">&nbsp;</p>
    <h1 class="text-center mt-5 pt-5 text-uppercase text-success">
        <small>Welcome to</small><br />
        Bus Trip Company
    </h1>
</div>

<?php require_once('footer.php') ?>