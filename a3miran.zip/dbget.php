<?php
function in_arrayi($needle, $haystack) {
    return in_array(strtolower($needle), array_map('strtolower', $haystack));
}

function rs2table($result, $table_class='', $thead_class='thead-light', $table_id=''){
    if ($result){
        $table_id == '' ? $id='' : $id="id='$table_id'";
        // echo "<div class='table-responsive'>";
        
        echo "<table $id class='table $table_class table-hover'>"; // table-responsive
        echo "<thead class='$thead_class'><tr>";
        $columns = mysqli_fetch_fields($result);
        foreach($columns as $col){
            echo "<th class='nowrap'>" . ucwords(str_replace('_', ' ', $col->name)) . "</th>";
        }
        echo "</tr></thead>";
    
        while($row = $result->fetch_assoc()) {
            
            echo "<tr>";
            foreach($columns as $col){
                $val = $row[$col->name];
                echo "<td>$val</td>";
            }
            echo "</tr>";   
        }
        echo "</table>";
        // echo "</div>";
    } else { echo "<h2 class='text-info text-center'>No record found</h2>"; }
}

function list_trips () {
    $sql = "SELECT 
                trip.trip_id, start_date, end_date, country, trip_name,
                trip.license_plate, capacity, 
                CASE WHEN COUNT(booking.trip_id) = 0 THEN 'NOBOOKING' ELSE COUNT(booking.trip_id) END reserved
            FROM 
                trip 
                JOIN bus ON trip.license_plate = bus.license_plate
                LEFT JOIN booking ON trip.trip_id = booking.trip_id
            GROUP BY
                trip.trip_id";
    $result = $GLOBALS['conn']->query($sql);
    return $result;
}

function list_bookings () {
    $sql = "SELECT booking.trip_id, booking.passenger_id, concat(first_name, ' ', last_name) passenger_name, trip_name, country, price FROM trip 
    JOIN booking ON trip.trip_id = booking.trip_id
    JOIN passenger ON booking.passenger_id = passenger.passenger_id ";
    $result = $GLOBALS['conn']->query($sql);
    return $result;
}

function list_passengers () {
    $sql = "SELECT 
                passenger_id, first_name, last_name, 
                date_of_birth, citizenship, passport.passport_number, expiry_date 
            FROM passenger JOIN passport USING (passport_number) 
            ORDER BY last_name";
    $result = $GLOBALS['conn']->query($sql);
    return $result;
}

function format_label($key)
{
    return ucwords(str_replace('_', ' ', str_replace('_id', '', $key)));
}

function generate_dropdown($name, $index='', $sql=''){ 

    if ($sql != '') {
        $result = dbselect($sql);
        $options = $result->fetch_all();
    }

    $html = '';
    foreach($options as $key=>$val){
        $k = $key; $v = $val;
        if (is_array($val)){ $k = $val[0]; $v = $val[1]; }
        if ($index == $k) $selected = 'selected'; else $selected = '';
        $html .= "<option $selected value='$k'>$v</option>";
    }
    return $html;
}

