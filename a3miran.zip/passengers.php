<?php
require_once('db.php');
require_once('header.php');
require_once('dbget.php') 
?>

<div class="row justify-content-md-center mt-4">
    <div class="col-md-12">
        <h3 class="mb-3">Passengers</h3>
        <?php
        rs2table(list_passengers(), $table_class='table', $thead_class='thead-light', $table_id='datagrid');
        ?>
    </div>
</div>

<?php require_once('footer.php') ?>

<!-- DataTables & Plugins -->
<script src="./js/datatables.min.js"></script>
<script src='js/utils.js?v=<?php echo date("ymd-Gi", filemtime("js/utils.js")) ?>'></script>

<!-- Page specific script -->

<script>
  
  $(function() {
    
    dataTable = $('#datagrid').DataTable({
      paging: false,
      lengthChange: false,
      searching: true,
      ordering: true,
      info: true,
      autoWidth: false,
      responsive: true,
      oLanguage: {
        sSearch: ""
      },
      dom: '<"pull-right"B><"top"f>tpi',
      buttons: [
        // {
        //   text: '<i class="fa fa-plus-circle mr-1"></i> New Trip',
        //   className: 'btn-success mr-2',
        //   action: function(e, dt, node, config) {
        //     frm_trip();
        //   }
        // }
      ]

    });

    $('#datagrid tbody').on('click', 'tr', function () {
      var data = dataTable.row( this ).data();
      // window.location = 'detail.php?id=' + data[0];
      // frm_passenger('view', data[0]);
      post('bookings.php?q=' + data[1] + ' ' + data[2])
    } );

  });
</script>
