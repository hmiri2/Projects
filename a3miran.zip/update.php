<?php
 
    if(!isset($_POST['table'])) header("Location:index.php");
    require_once('db.php');
    
    try {
        if($_POST['action']=='add')
            $result = insert($_POST['table'], $_POST);
        else
            $result = insert_or_update($_POST['table'], $_POST);
        
        if (!$result[0]) {
            require_once ('header.php');
            echo "<div class='text-center w-50 mx-auto mt-5'>";
            echo "<h4 class='text-danger'>Error while processing.</h4>";
            echo "<h6>". $result[1] ."</h6>";
            echo "<a class='btn btn-primary'  href='". $_POST['callback'] ."'>Go Back</a>";  
            echo "</div>";
            require_once ('footer.php');
            exit;
        };

    } catch (\Throwable $th) {
        die($th);
    }

    header('Location:' . $_POST['callback']);
?>