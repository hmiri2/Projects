
var library = {
  pokemon: [
    'https://res.cloudinary.com/beumsk/image/upload/v1547980025/memory/Pokemon/Bulbasaur.png',
    'https://res.cloudinary.com/beumsk/image/upload/v1547980083/memory/Pokemon/Charmander.png',
    'https://res.cloudinary.com/beumsk/image/upload/v1547980101/memory/Pokemon/Squirtle.png',
    'https://res.cloudinary.com/beumsk/image/upload/v1547980116/memory/Pokemon/Pikachu.png',
    'https://res.cloudinary.com/beumsk/image/upload/v1547980129/memory/Pokemon/Mewtwo.png',
    'https://res.cloudinary.com/beumsk/image/upload/v1547980142/memory/Pokemon/Mew.png',
    'https://res.cloudinary.com/beumsk/image/upload/v1547980154/memory/Pokemon/Articuno.png',
    'https://res.cloudinary.com/beumsk/image/upload/v1547980164/memory/Pokemon/Zapdos.png',
    'https://res.cloudinary.com/beumsk/image/upload/v1547980175/memory/Pokemon/Moltres.png',
    'https://res.cloudinary.com/beumsk/image/upload/v1547980186/memory/Pokemon/Eevee.png',
    'https://res.cloudinary.com/beumsk/image/upload/v1547980025/memory/Pokemon/Bulbasaur.png',
    'https://res.cloudinary.com/beumsk/image/upload/v1547980083/memory/Pokemon/Charmander.png',
    'https://res.cloudinary.com/beumsk/image/upload/v1547980101/memory/Pokemon/Squirtle.png',
    'https://res.cloudinary.com/beumsk/image/upload/v1547980116/memory/Pokemon/Pikachu.png',
    'https://res.cloudinary.com/beumsk/image/upload/v1547980129/memory/Pokemon/Mewtwo.png',
    'https://res.cloudinary.com/beumsk/image/upload/v1547980142/memory/Pokemon/Mew.png',
    'https://res.cloudinary.com/beumsk/image/upload/v1547980154/memory/Pokemon/Articuno.png',
    'https://res.cloudinary.com/beumsk/image/upload/v1547980164/memory/Pokemon/Zapdos.png',
    'https://res.cloudinary.com/beumsk/image/upload/v1547980175/memory/Pokemon/Moltres.png',
    'https://res.cloudinary.com/beumsk/image/upload/v1547980186/memory/Pokemon/Eevee.png'
  ],
  starwars: [
    'https://res.cloudinary.com/beumsk/image/upload/v1547980981/memory/starwars/anakin%20skywalker.jpg',
    'https://res.cloudinary.com/beumsk/image/upload/v1547981009/memory/starwars/luke%20skywalker.jpg',
    'https://res.cloudinary.com/beumsk/image/upload/v1547981022/memory/starwars/Obi%20wann.jpg',
    'https://res.cloudinary.com/beumsk/image/upload/v1547981054/memory/starwars/Han%20solo.jpg',
    'https://res.cloudinary.com/beumsk/image/upload/v1547981074/memory/starwars/chewbacca.jpg',
    'https://res.cloudinary.com/beumsk/image/upload/v1547981095/memory/starwars/yoda.jpg',
    'https://res.cloudinary.com/beumsk/image/upload/v1547981117/memory/starwars/dark%20sidious.jpg',
    'https://res.cloudinary.com/beumsk/image/upload/v1547981141/memory/starwars/dark%20vador.jpg',
    'https://res.cloudinary.com/beumsk/image/upload/v1547981165/memory/starwars/padme.jpg',
    'https://res.cloudinary.com/beumsk/image/upload/v1547981190/memory/starwars/leia.jpg',
    'https://res.cloudinary.com/beumsk/image/upload/v1547980981/memory/starwars/anakin%20skywalker.jpg',
    'https://res.cloudinary.com/beumsk/image/upload/v1547981009/memory/starwars/luke%20skywalker.jpg',
    'https://res.cloudinary.com/beumsk/image/upload/v1547981022/memory/starwars/Obi%20wann.jpg',
    'https://res.cloudinary.com/beumsk/image/upload/v1547981054/memory/starwars/Han%20solo.jpg',
    'https://res.cloudinary.com/beumsk/image/upload/v1547981074/memory/starwars/chewbacca.jpg',
    'https://res.cloudinary.com/beumsk/image/upload/v1547981095/memory/starwars/yoda.jpg',
    'https://res.cloudinary.com/beumsk/image/upload/v1547981117/memory/starwars/dark%20sidious.jpg',
    'https://res.cloudinary.com/beumsk/image/upload/v1547981141/memory/starwars/dark%20vador.jpg',
    'https://res.cloudinary.com/beumsk/image/upload/v1547981165/memory/starwars/padme.jpg',
    'https://res.cloudinary.com/beumsk/image/upload/v1547981190/memory/starwars/leia.jpg'
  ],
  lotr: [
    'https://res.cloudinary.com/beumsk/image/upload/v1547981408/memory/lotr/gandalf.jpg',
    'https://res.cloudinary.com/beumsk/image/upload/v1547981438/memory/lotr/sauron.jpg',
    'https://res.cloudinary.com/beumsk/image/upload/v1547981469/memory/lotr/Aragorn.jpg',
    'https://res.cloudinary.com/beumsk/image/upload/v1547981501/memory/lotr/legolas.jpg',
    'https://res.cloudinary.com/beumsk/image/upload/v1547981535/memory/lotr/Gimli.jpg',
    'https://res.cloudinary.com/beumsk/image/upload/v1547981603/memory/lotr/golum.jpg',
    'https://res.cloudinary.com/beumsk/image/upload/v1547981645/memory/lotr/sam.jpg',
    'https://res.cloudinary.com/beumsk/image/upload/v1547981686/memory/lotr/saroumane.jpg',
    'https://res.cloudinary.com/beumsk/image/upload/v1547981738/memory/lotr/bilbo.jpg',
    'https://res.cloudinary.com/beumsk/image/upload/v1547981802/memory/lotr/frodo.jpg',
    'https://res.cloudinary.com/beumsk/image/upload/v1547981408/memory/lotr/gandalf.jpg',
    'https://res.cloudinary.com/beumsk/image/upload/v1547981438/memory/lotr/sauron.jpg',
    'https://res.cloudinary.com/beumsk/image/upload/v1547981469/memory/lotr/Aragorn.jpg',
    'https://res.cloudinary.com/beumsk/image/upload/v1547981501/memory/lotr/legolas.jpg',
    'https://res.cloudinary.com/beumsk/image/upload/v1547981535/memory/lotr/Gimli.jpg',
    'https://res.cloudinary.com/beumsk/image/upload/v1547981603/memory/lotr/golum.jpg',
    'https://res.cloudinary.com/beumsk/image/upload/v1547981645/memory/lotr/sam.jpg',
    'https://res.cloudinary.com/beumsk/image/upload/v1547981686/memory/lotr/saroumane.jpg',
    'https://res.cloudinary.com/beumsk/image/upload/v1547981738/memory/lotr/bilbo.jpg',
    'https://res.cloudinary.com/beumsk/image/upload/v1547981802/memory/lotr/frodo.jpg'
  ],
  disney: [
    'https://res.cloudinary.com/beumsk/image/upload/v1547982044/memory/disney/mickey.jpg',
    'https://res.cloudinary.com/beumsk/image/upload/v1547982088/memory/disney/mowgli.jpg',
    'https://res.cloudinary.com/beumsk/image/upload/v1547982610/memory/disney/tarzan.jpg',
    'https://res.cloudinary.com/beumsk/image/upload/v1547982620/memory/disney/simba.jpg',
    'https://res.cloudinary.com/beumsk/image/upload/v1547982628/memory/disney/aladin.jpg',
    'https://res.cloudinary.com/beumsk/image/upload/v1547982636/memory/disney/blanche%20neige.jpg',
    'https://res.cloudinary.com/beumsk/image/upload/v1547982644/memory/disney/alice.png',
    'https://res.cloudinary.com/beumsk/image/upload/v1547982653/memory/disney/peter%20pan.jpg',
    'https://res.cloudinary.com/beumsk/image/upload/v1547982663/memory/disney/pinocchio.jpg',
    'https://res.cloudinary.com/beumsk/image/upload/v1547982738/memory/disney/raiponce.jpg',
    'https://res.cloudinary.com/beumsk/image/upload/v1547982044/memory/disney/mickey.jpg',
    'https://res.cloudinary.com/beumsk/image/upload/v1547982088/memory/disney/mowgli.jpg',
    'https://res.cloudinary.com/beumsk/image/upload/v1547982610/memory/disney/tarzan.jpg',
    'https://res.cloudinary.com/beumsk/image/upload/v1547982620/memory/disney/simba.jpg',
    'https://res.cloudinary.com/beumsk/image/upload/v1547982628/memory/disney/aladin.jpg',
    'https://res.cloudinary.com/beumsk/image/upload/v1547982636/memory/disney/blanche%20neige.jpg',
    'https://res.cloudinary.com/beumsk/image/upload/v1547982644/memory/disney/alice.png',
    'https://res.cloudinary.com/beumsk/image/upload/v1547982653/memory/disney/peter%20pan.jpg',
    'https://res.cloudinary.com/beumsk/image/upload/v1547982663/memory/disney/pinocchio.jpg',
    'https://res.cloudinary.com/beumsk/image/upload/v1547982738/memory/disney/raiponce.jpg'
  ],
  pixar: [
    'https://res.cloudinary.com/beumsk/image/upload/v1547982971/memory/pixar/up.jpg',
    'https://res.cloudinary.com/beumsk/image/upload/v1547982987/memory/pixar/buzz.jpg',
    'https://res.cloudinary.com/beumsk/image/upload/v1547983000/memory/pixar/woody.jpg',
    'https://res.cloudinary.com/beumsk/image/upload/v1547983016/memory/pixar/Remy.jpg',
    'https://res.cloudinary.com/beumsk/image/upload/v1547983032/memory/pixar/Mike.jpg',
    'https://res.cloudinary.com/beumsk/image/upload/v1547983077/memory/pixar/Nemo.jpg',
    'https://res.cloudinary.com/beumsk/image/upload/v1547983114/memory/pixar/wall-e.png',
    'https://res.cloudinary.com/beumsk/image/upload/v1547983169/memory/pixar/Mr-Incredible.jpg',
    'https://res.cloudinary.com/beumsk/image/upload/v1547983381/memory/pixar/sully.jpg',
    'https://res.cloudinary.com/beumsk/image/upload/v1547983403/memory/pixar/flash%20mcqueen.jpg',
    'https://res.cloudinary.com/beumsk/image/upload/v1547982971/memory/pixar/up.jpg',
    'https://res.cloudinary.com/beumsk/image/upload/v1547982987/memory/pixar/buzz.jpg',
    'https://res.cloudinary.com/beumsk/image/upload/v1547983000/memory/pixar/woody.jpg',
    'https://res.cloudinary.com/beumsk/image/upload/v1547983016/memory/pixar/Remy.jpg',
    'https://res.cloudinary.com/beumsk/image/upload/v1547983032/memory/pixar/Mike.jpg',
    'https://res.cloudinary.com/beumsk/image/upload/v1547983077/memory/pixar/Nemo.jpg',
    'https://res.cloudinary.com/beumsk/image/upload/v1547983114/memory/pixar/wall-e.png',
    'https://res.cloudinary.com/beumsk/image/upload/v1547983169/memory/pixar/Mr-Incredible.jpg',
    'https://res.cloudinary.com/beumsk/image/upload/v1547983381/memory/pixar/sully.jpg',
    'https://res.cloudinary.com/beumsk/image/upload/v1547983403/memory/pixar/flash%20mcqueen.jpg'
  ],
  harrypotter: [
    'https://res.cloudinary.com/beumsk/image/upload/v1547998926/memory/harrypotter/harry.jpg',
    'https://res.cloudinary.com/beumsk/image/upload/v1547998958/memory/harrypotter/ron.jpg',
    'https://res.cloudinary.com/beumsk/image/upload/v1547998992/memory/harrypotter/hermione.jpg',
    'https://res.cloudinary.com/beumsk/image/upload/v1547999106/memory/harrypotter/dumbledore.jpg',
    'https://res.cloudinary.com/beumsk/image/upload/v1547999032/memory/harrypotter/malfoy.jpg',
    'https://res.cloudinary.com/beumsk/image/upload/v1547999143/memory/harrypotter/voldemort.jpg',
    'https://res.cloudinary.com/beumsk/image/upload/v1547999401/memory/harrypotter/rogue.jpg',
    'https://res.cloudinary.com/beumsk/image/upload/v1547999196/memory/harrypotter/hagrid.jpg',
    'https://res.cloudinary.com/beumsk/image/upload/v1547999271/memory/harrypotter/sirius.jpg',
    'https://res.cloudinary.com/beumsk/image/upload/v1547999577/memory/harrypotter/neville.jpg',
    'https://res.cloudinary.com/beumsk/image/upload/v1547998926/memory/harrypotter/harry.jpg',
    'https://res.cloudinary.com/beumsk/image/upload/v1547998958/memory/harrypotter/ron.jpg',
    'https://res.cloudinary.com/beumsk/image/upload/v1547998992/memory/harrypotter/hermione.jpg',
    'https://res.cloudinary.com/beumsk/image/upload/v1547999106/memory/harrypotter/dumbledore.jpg',
    'https://res.cloudinary.com/beumsk/image/upload/v1547999032/memory/harrypotter/malfoy.jpg',
    'https://res.cloudinary.com/beumsk/image/upload/v1547999143/memory/harrypotter/voldemort.jpg',
    'https://res.cloudinary.com/beumsk/image/upload/v1547999401/memory/harrypotter/rogue.jpg',
    'https://res.cloudinary.com/beumsk/image/upload/v1547999196/memory/harrypotter/hagrid.jpg',
    'https://res.cloudinary.com/beumsk/image/upload/v1547999271/memory/harrypotter/sirius.jpg',
    'https://res.cloudinary.com/beumsk/image/upload/v1547999577/memory/harrypotter/neville.jpg'
  ]
}

var images = [];
var tempElt1 = "";
var tempElt2 = "";
var click = -1;
var win = 0;
var score = 0;
var time = 100;
  
  // settings variables
  var limit = 300;
  var width = 5;
  var height = 4;
  var grid = "5X4"

// First, create an audio element and set its source to the audio file you want to play.
const audio = new Audio('https://res.cloudinary.com/dz5nd2z2f/video/upload/v1680850529/start_lnn2dm.mp3');
const audio2 = new Audio('https://res.cloudinary.com/dz5nd2z2f/video/upload/v1680850704/click-card_t7vmpv.mp3');
const audio3 = new Audio('https://res.cloudinary.com/dz5nd2z2f/video/upload/v1680850529/wrong_tlafr7.mp3');    
const audio4 = new Audio('https://res.cloudinary.com/dz5nd2z2f/video/upload/v1680850529/correct_gwrt8y.mp3');

var menuElt = document.querySelector("#menu");
var preElt = document.querySelector("#pre");
var themesElt = document.querySelector("#themes");
var mainElt = document.getElementById(grid);
var mainElts = document.getElementsByClassName("main");
var boxElts = mainElt.getElementsByClassName("box");
//var boxElts = document.getElementsByClassName("box");
//var mainElt = document.querySelector(".main");
var leaveElt = document.getElementById("leaderleave");
var logoElt = document.querySelector(".logo");
var supElt = document.querySelector(".supportmain");
var timeElt = document.querySelector("#time");
var scoreElt = document.querySelector("#score");
var postElt = document.querySelector("#post");
var finalElt = document.querySelector("#final");
var againElt = document.querySelector("#again");
var settingsElt = document.querySelector("#settings");
var exitElt = document.querySelector("#exit");
var eTRElt = document.querySelector(".exitTopRight");

// HELP CODE;
// Get the main modal
var modal = document.getElementById("modal");

// Get the button that opens the main modal
var btn = document.getElementById("help");

// Get the <span> element that closes the main modal
var span = document.getElementsByClassName("close")[0];

// Get the button that shows the example image
var correctBtn = document.getElementById("show-correct-btn");


// Get the example image
//var exampleImg = document.getElementById("correct-match-img");

// Get the second modal
var exampleModal = document.getElementById("example-modal");

// Get the <span> element that closes the second modal
var exampleSpan = exampleModal.getElementsByClassName("close")[0];

const promptContainer = document.getElementById("prompt-container");
var nameInput = document.getElementById("name");
    const startButton = document.getElementById("start-button");
// const Player = nameInput.textContent;




function updateGridSize(g, w, h) {
  width = w;
  height = h;
  grid = g;
  document.querySelector("#GridSize").textContent = g;

  mainElt = document.getElementById(grid);
  boxElts = mainElt.getElementsByClassName("box");
  timeElt = mainElt.querySelector("#time");
  scoreElt = mainElt.querySelector("#score");
}

function updateTimeLimit(t) {
  limit = t;
  document.querySelector("#TimeLimit").textContent = t;
}

function updateColour(colour) {
  if (colour == "default") {
    document.querySelector("#Colour").textContent = "Default";
    document.documentElement.style.setProperty('--themeColour', '#09558e');
    document.documentElement.style.setProperty('--themeBackground', 'white');
    document.documentElement.style.setProperty('--themeHoverColour', 'white');
    document.documentElement.style.setProperty('--themeHoverBackground', '#09558e');
  }
  else if (colour == "light") {
    document.querySelector("#Colour").textContent = "Light";
    document.documentElement.style.setProperty('--themeColour', 'black');
    document.documentElement.style.setProperty('--themeBackground', 'white');
    document.documentElement.style.setProperty('--themeHoverColour', 'black');
    document.documentElement.style.setProperty('--themeHoverBackground', '#ddd');
  }
  else if (colour == "dark") {
    document.querySelector("#Colour").textContent = "Dark";
    document.documentElement.style.setProperty('--themeColour', 'grey');
    document.documentElement.style.setProperty('--themeBackground', 'black');
    document.documentElement.style.setProperty('--themeHoverColour', 'black');
    document.documentElement.style.setProperty('--themeHoverBackground', 'grey');
  }
}

function updateFont(font) {
  if (font == "default") {
    document.querySelector("#Font").textContent = "Default";
    document.documentElement.style.setProperty('--themeFont', '"Brush Script MT", Cursive');
  }
  else if (font == "arial") {
    document.querySelector("#Font").textContent = "Arial";
    document.documentElement.style.setProperty('--themeFont', '"Brush Script MT", Arial');
  }
  else if (font == "times") {
    document.querySelector("#Font").textContent = "Times";
    document.documentElement.style.setProperty('--themeFont', '"Brush Script MT", Times');
  }
}


// initiate the game with chosen theme
themesElt.addEventListener("click", function(e) {
  if (e.target.classList.contains("themes")) {
    activateTheme(e.target.id);
    preElt.classList.add("hidden");
  }
});

startButton.addEventListener("click", function() {
  gameAudio();
  const Player = nameInput.value;
  addNameToLeaderboard(Player);
  promptContainer.style.display = "none";
});
    
  // Function to add a new row to the leaderboard table with the given name
  function addNameToLeaderboard(nameInput) {
   // Get the leaderboard table element
   const leaderboardTable = document.getElementById("table");
    // Loop through existing rows to check if name already exists
    for (let i = 1; i < leaderboardTable.rows.length; i++) {
      if (leaderboardTable.rows[i].cells[1].textContent === Player) {
        return; // Name already exists, exit function without adding row
      }
    }
    // Create a new row element
    const newRow = leaderboardTable.insertRow();
    // Create 4 new cell elements
    var rankCell = newRow.insertCell(0);
    var nameCell = newRow.insertCell(1);
    var scoreCell = newRow.insertCell(2);
    var timeCell = newRow.insertCell(3);
    // Set the text content of the name cell to the given name
    rankCell.textContent = "1";
    nameCell.textContent = nameInput;
    scoreCell.textContent = "0";
    timeCell.textContent = "0";

  }
  

function activateTheme(theme) {
  // insert theme in images array
    var image = 0;
    while (images.length < (width*height)) {
      images.push(library[theme][image]);
      images.push(library[theme][image]);
      image++;
      if (image == 10) {image = 0;}
      console.log("image");
    }
    // insert images in memory game
    for (let i = 0; i < (width*height); i++) {
      var rand = Math.floor(Math.random() * (images.length - 1));
      boxElts[i].innerHTML = '';
      boxElts[i].innerHTML = "<img src='" + images[rand] + "' alt='https://rb.gy/yktdca' class='play'>";
      var temp = boxElts[i].firstChild.src;
      boxElts[i].firstChild.src = boxElts[i].firstChild.alt;
      boxElts[i].firstChild.alt = temp;
      images.splice(rand, 1);
    }
}

 
// Start a new game
  function newLogic() {
    
    for (let i = 0; i < 5; i++) {
      mainElts[i].classList.add("hidden");
    }
    mainElt.classList.remove("hidden");
    menuElt.style.visibility='hidden';
    mainElt.style.filter = 'blur(0px)';
    logoElt.style.filter = 'blur(0px)';
    eTRElt.style.filter = 'blur(0px)';
    preElt.classList.remove("hidden");
    
    // Handle the play
    mainElt.addEventListener("click", gameLogic);
  }

function exitButton() {
  if(exitElt.classList.contains("hidden")) {
    menuElt.classList.add("hidden");
    exitElt.classList.remove("hidden");
    document.getElementById("defaultTab").click();
  }
  else {
    exitElt.classList.add("hidden");
    menuElt.classList.remove("hidden");
  }
}
function exitWindow() {
  close();
}


function gameClose() {
  window.close();
}

//
function leaderboard() {
  if(leaderleave.classList.contains("hidden")){
    menuElt.classList.add("hidden");
    leaderleave.classList.remove("hidden");
    modal.classList.add("hidden");
    mainElt.classList.remove("hidden")
  } else {
    menuElt.classList.remove("hidden");
    leaderleave.classList.add("hidden");
  }
}

// Handle the play
mainElt.addEventListener("click", gameLogic);


// Open settings menu
function settings() {
  if (settingsElt.classList.contains("hidden")) {
      menuElt.classList.add("hidden");
    mainElt.classList.add("hidden");
      settingsElt.classList.remove("hidden");
    modal.classList.add("hidden");
      document.getElementById("defaultTab").click();
  } else {
      settingsElt.classList.add("hidden");
      menuElt.classList.remove("hidden");
      mainElt.classList.remove("hidden");
  }
}

// settings tabs
function openTab(evt, tab) {

  var i, tabcontent, tablinks;

  tabcontent = document.getElementsByClassName("tabcontent");
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";
  }

  tablinks = document.getElementsByClassName("tablinks");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].className = tablinks[i].className.replace(" active", "");
  }

  document.getElementById(tab).style.display = "block";
  evt.currentTarget.className += " active";
}


function gameLogic(e) {
    // make sure the box is playable
    if (e.target.classList.contains("play")) {
      console.log(e.target);
      var temp = e.target.src;
      e.target.src = e.target.alt;
      e.target.alt = temp;
      //e.target.firstChild.classList.remove("hidden");
      // first of two click
      if (click < 1) {
        CardClicked();
        tempElt1 = e.target;
        // timer
        if (click === -1) {
          timer = setInterval(function() {
            time--;
            timeElt.innerHTML = time;
            if (time == 0) { // END THE GAME
              clearInterval(timer);
            //finalElt.innerHTML = "You lost.\n " + score + " points <br>";
            postElt.classList.remove("hidden");
            }
          }, 1000);
        }
        click = 1;
      }
  
      // second click
      else if (e.target !== tempElt1) {
          CardClicked();
  
        tempElt2 = e.target;
  
        // different images
        if (tempElt1.src !== tempElt2.src) {
          mainElt.removeEventListener("click", gameLogic);
          setTimeout( function() {
            tempElt1.classList.add("outlinedred");
            tempElt2.classList.add("outlinedred");
            //tempElt1.firstChild.classList.add("hidden");
            //tempElt2.firstChild.classList.add("hidden");
            //mainElt.addEventListener("click", gameLogic);
          }, 400);
          
          setTimeout( function() {
            var temp1 = tempElt1.src;
            var temp2 = tempElt2.src;
            tempElt1.src = tempElt1.alt;
            tempElt1.alt = temp1;
            tempElt2.src = tempElt2.alt;
            tempElt2.alt = temp2;
            tempElt1.classList.remove("outlinedred");
            tempElt2.classList.remove("outlinedred");
            mainElt.addEventListener("click", gameLogic);
          }, 800);
          
          if (score > 0) {
            score -= 2;
          }
          scoreElt.innerHTML = score;
        }
  
        // same images
        else {
          score += 10;
          win += 2;
          time += 20;
          tempElt1.classList.add("outlinedgreen");
          tempElt2.classList.add("outlinedgreen");
          tempElt1.classList.remove("play");
          tempElt2.classList.remove("play");
          scoreElt.innerHTML = score;
  
          // game won
          if (win === (width*height)) {
            clearInterval(timer);
              // Update the time label with the current time
              const timeLabel = document.getElementById("timer");
              
              timeLabel.textContent = time;

                // Update the score label with the player's score
              const scoreLabel = document.getElementById("scorer");
              
              scoreLabel.textContent = score; 
            postElt.classList.remove("hidden");
          }
        }
        click = 0;
      }
    }
  }

if(againElt) {
  againElt.addEventListener("click", resetGame);
}

// Then, in your game code, when the game is won, call the `play` method on the audio element to play the audio.
  function gameAudio() {
    // code to handle game win
    audio.play(); // play the audio file
  }
      
  function CardClicked() {
    audio2.play(); // play the audio file
  }
  function MissMatch() {
    audio3.play(); // play the audio file
  }
  function Amatch() {
    audio4.play(); // play the audio file
  }


  function AddScore(score){

    scoreElt.textContent = score;
  }

  function AddTime(time){
    timeElt.textContent = time;
  }
  

function resetGame() {
  // reset game
  tempElt1 = "";
  tempElt2 = "";
  click = -1;
  win = 0;
  score = 0;
  time = 100;
  postElt.classList.add("hidden");
  preElt.classList.remove("hidden");
  for (let i = 0; i < 20; i++) {
    boxElts[i].classList.add("play");
    boxElts[i].firstChild.classList.add("hidden");
  }
  timeElt.textContent = time;
  scoreElt.textContent = score;
}


/***************For the Congrats container/OpenSource********************** */
const Confettiful = function(el) {
  this.el = el;
  this.containerEl = null;
  
  this.confettiFrequency = 3;
  this.confettiColors = ['#EF2964', '#00C09D', '#2D87B0', '#48485E','#EFFF1D'];
  this.confettiAnimations = ['slow', 'medium', 'fast'];
  
  //this._setupElements();
  this._renderConfetti();
};

/*Confettiful.prototype._setupElements = function() {
  const containerEl = document.createElement('div');
  //const elPosition = this.el.style.position;
  
  if (elPosition !== 'relative' || elPosition !== 'absolute') {
    this.el.style.position = 'relative';
  }
  
  containerEl.classList.add('confetti-container');
  
  this.el.appendChild(containerEl);
  
  this.containerEl = containerEl;
};*/



// handle focus of the page
// function checkPageFocus() {
//   if (document.hasFocus()) {
//     preElt.classList.remove("hidden");
//   }
//   else {
//     preElt.classList.add("hidden");
//   }
// }
// var checkPageInterval = setInterval(checkPageFocus, 300);

// When the user clicks the button, open the main
// modal
btn.onclick = function() {
  modal.classList.remove("hidden");
  menuElt.classList.add("hidden");
  mainElt.classList.add("hidden")
modal.style.display = "block";
}

function help() {
  modal.classList.remove("hidden");
  menuElt.classList.add("hidden");
  mainElt.classList.add("hidden")
modal.style.display = "block";
}

// When the user clicks on <span> (x), close the main modal
span.onclick = function() {
modal.style.display = "none";
  menuElt.classList.remove("hidden");
  mainElt.classList.remove("hidden")
}

// When the user clicks the "Show Example" button, show the example image
correctBtn.onclick = function() {
//exampleImg.style.display = "block";
exampleModal.style.display = "block";
}

// When the user clicks on <span> (x), close the second modal
exampleSpan.onclick = function() {
exampleModal.style.display = "none";
}

// When the user clicks anywhere outside of the modals, close them
window.onclick = function(event) {

if (event.target == modal && exampleModal.style.display == "none") {
modal.style.display = "none";
}
if (event.target == exampleModal) {
exampleModal.style.display = "none";
}
}