# Mergesort-Algorithm-Game
An educational game in a web application that helps the player understand merge sort algorithm
